﻿// Negocio/TiendaService.cs
using System.Collections.Generic;

public class TiendaService
{
    private readonly TiendaRepository _tiendaRepository;

    public TiendaService(TiendaRepository tiendaRepository)
    {
        _tiendaRepository = tiendaRepository;
    }

    public IEnumerable<Tienda> ObtenerTodasTiendas()
    {
        return _tiendaRepository.ObtenerTodas();
    }

    
}
