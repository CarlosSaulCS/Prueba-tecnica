﻿// Negocio/ArticuloService.cs
using System.Collections.Generic;

public class ArticuloService
{
    private readonly ArticuloRepository _articuloRepository;

    public ArticuloService(ArticuloRepository articuloRepository)
    {
        _articuloRepository = articuloRepository;
    }

    public IEnumerable<Articulo> ObtenerTodosArticulos()
    {
        return _articuloRepository.ObtenerTodos();
    }

    
}
