﻿// Negocio/ClienteService.cs
using System;
using System.Collections.Generic;

public class ClienteService
{
    private readonly ClienteRepository _clienteRepository;

    public ClienteService(ClienteRepository clienteRepository)
    {
        _clienteRepository = clienteRepository;
    }

    public IEnumerable<Cliente> ObtenerTodosClientes()
    {
        return _clienteRepository.ObtenerTodos();
    }

    public Cliente ObtenerClientePorId(int clienteId)
    {
        return _clienteRepository.ObtenerPorId(clienteId);
    }

    public void AgregarCliente(Cliente cliente)
    {
        
        _clienteRepository.Agregar(cliente);
    }

    
}