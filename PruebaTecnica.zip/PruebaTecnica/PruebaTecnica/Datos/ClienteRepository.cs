﻿// Datos/ClienteRepository.cs
using System.Collections.Generic;
using System.Linq;

public class ClienteRepository
{
    private readonly AppDbContext _context;

    public ClienteRepository(AppDbContext context)
    {
        _context = context;
    }

    public IEnumerable<Cliente> ObtenerTodos()
    {
        return _context.Clientes.ToList();
    }

    public Cliente ObtenerPorId(int clienteId)
    {
        return _context.Clientes.FirstOrDefault(c => c.ClienteId == clienteId);
    }

    public void Agregar(Cliente cliente)
    {
        _context.Clientes.Add(cliente);
        _context.SaveChanges();
    }

   
}