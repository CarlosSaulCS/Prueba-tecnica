﻿// Datos/AppDbContext.cs
using System.Collections.Generic;
using System.Runtime.Remoting.Contexts;
using Microsoft.EntityFrameworkCore;

public class AppDbContext : DbContext
{
    public AppDbContext(DbContextOptions<AppDbContext> options) : base(options)
    {
    }

    public DbSet<Cliente> Clientes { get; set; }
    public DbSet<Tienda> Tiendas { get; set; }
    public DbSet<Articulo> Articulos { get; set; }
    public DbSet<RelacionArticuloTienda> RelacionArticuloTiendas { get; set; }
    public DbSet<RelacionClienteArticulo> RelacionClienteArticulos { get; set; }
}
